const chatForm = document.querySelector("#chat-form");
const messageInput = document.querySelector("#message-input");
const messages = document.querySelector("#messages");
const statusText = document.querySelector("#status");

function addMessage(text, role) {
  const bubble = document.createElement("div");
  bubble.className = `message ${role}`;
  bubble.textContent = text;
  messages.appendChild(bubble);
  messages.scrollTop = messages.scrollHeight;
}

function demoReply(message) {
  const q = message.toLowerCase();
  if (q.includes("হ্যালো") || q.includes("hello") || q.includes("hi")) {
    return "হ্যালো! আমি বন্ধু AI-এর প্রাথমিক সংস্করণ। কীভাবে সাহায্য করতে পারি?";
  }
  if (q.includes("তোমার নাম") || q.includes("তোমাকে কী বলে")) {
    return "আমার নাম বন্ধু AI। আমি তোমার বাংলা ও ইংরেজি সহায়ক হওয়ার জন্য তৈরি হচ্ছি।";
  }
  if (q.includes("কী করতে") || q.includes("কি করতে")) {
    return "এই সংস্করণে চ্যাট ইন্টারফেস কাজ করছে। আসল AI উত্তর পেতে পরে নিরাপদ সার্ভার থেকে AI API যুক্ত করতে হবে।";
  }
  return "তোমার মেসেজ পেয়েছি! আপাতত এটি ডেমো মোড—এখনো কোনো AI সার্ভিসের সঙ্গে যুক্ত নয়। আসল AI উত্তর চালু করতে পরের ধাপে নিরাপদ backend ও API সংযোগ করতে হবে।";
}

chatForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const message = messageInput.value.trim();
  if (!message) return;

  addMessage(message, "user");
  messageInput.value = "";
  statusText.textContent = "বন্ধু AI উত্তর তৈরি করছে…";

  window.setTimeout(() => {
    addMessage(demoReply(message), "bot");
    statusText.textContent = "ডেমো মোড";
  }, 450);
});

document.querySelectorAll("[data-prompt]").forEach((button) => {
  button.addEventListener("click", () => {
    messageInput.value = button.dataset.prompt;
    messageInput.focus();
  });
});

if ("serviceWorker" in navigator && location.protocol !== "file:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch((error) => {
      console.warn("Service worker registration failed:", error);
    });
  });
}
